Trabajo realizado por cada integrante.

1. Angel Oved Martínez Galindo - 20211930086:
Inicialmente trabajé en el módulo de Expedientes en el cual se integran las citas médicas, creé el módulo de Inicio de Inventario para la unión de Medicamentos y Equipos y también ofrecí mi apoyo en los demás módulos.

2. Joaquin David Buezo Rosa - 20211920098:
Trabajé en el inventario, más específicamente en la gestión de equipo implementando el módulo completo con sus funciones para poder guardar y almacenar el equipo en la cual se definen también los estados lugares y demás.

3. Lisandro Adolfo Cantarero Girón - 20201001693
Hice el esquema gráfico del proyecto en canva(Funcionalidades,Tablas y relaciones).
Hice la parte de inicio, es la página principal donde se accede a las funciones que tiene la clínica.

4. Angel Alexander Portillo Martínez - 20211920084
Realización del inventario de medicamentos funcional con sus respectivos campos sugeridos por el equipo empleado de la clínica.

5. Maria Fernanda Ordoñez Funez - 20171900165
Trabajé en el diseño del proyecto, para eso utilicé la aplicación de figma una herramienta de diseño colaborativa que permite crear interfaces modernas y funcionales.
Diseñé una interfaz intuitiva y fácil de usar que facilite la navegación para el personal médico, el cual los ayude a llevar un registro de los pacientes y también un inventario.
Creé un sistema visual coherente, utilizando una paleta de colores,  y elementos gráficos alineados con la identidad de la clínica CURAH.
