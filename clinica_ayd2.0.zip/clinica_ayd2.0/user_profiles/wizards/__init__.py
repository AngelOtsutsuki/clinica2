# -*- coding: utf-8 -*-
from . import wizard_create_profile
