from . import res_partner
from . import cita_medica
from . import inicio_medico
from . import medical_patient